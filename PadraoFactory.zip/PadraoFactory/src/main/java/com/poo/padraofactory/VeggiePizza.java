package com.poo.padraofactory;

public class VeggiePizza extends Pizza {
    public VeggiePizza(){
        name = "Veggie Pizza";
        dough = "Crust";
        sauce = "MArinara sauce";
        toppings.add("Shredded mozzarella");
        toppings.add("Grated Parmesan");
        toppings.add("Diced Onion");
        toppings.add("Slice mushrooms");
        toppings.add("Slice red pepper");
        toppings.add("Slice black olives");
    }
}

package com.poo.padraofactory;

public class ClamPizza extends Pizza {
    public ClamPizza(){
        name = "Clam Pizza";
        dough = "Thin crust";
        sauce = "White garlic sauce";
        toppings.add("Clam");
        toppings. add("Teste");
    }
}

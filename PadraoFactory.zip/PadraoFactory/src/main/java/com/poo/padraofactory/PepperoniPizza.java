package com.poo.padraofactory;


public class PepperoniPizza extends Pizza {
    public PepperoniPizza(){
        name = "Pepperoni Pizza";
        dough = "Crust";
        sauce = "Marinara Sauce";
        toppings.add("Slice Peperoni");
        toppings.add("Slice Onion");
        toppings.add("Grated Parmesan cheese");
    }
}

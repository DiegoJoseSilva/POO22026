package com.poo.padraofactory;

public class CheessePizza extends Pizza {
    
    public CheessePizza(){
    
        name = "Cheese Pizza";
        dough = "Regular Crust";
        sauce = "Marinara Pizza Sauce";
        toppings.add("Fresh Mozzarella");
        toppings.add("Parmesan"); 
    }
      
}

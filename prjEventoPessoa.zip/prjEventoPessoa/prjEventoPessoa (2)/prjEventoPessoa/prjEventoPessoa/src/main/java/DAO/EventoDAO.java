package DAO;

import Objetos.Eventos;
import Objetos.Pessoa;
import Util.Conexao;
import Util.ManipulaData;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EventoDAO {
    Connection conn;
    ManipulaData md;
    
    public EventoDAO(Connection conn, ManipulaData md) {
        conn= new Conexao().conectar();
        md = new ManipulaData();
    }
    
    public Eventos Salvar(Eventos e){
        try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO eventos(id_evento, nome, data) values(?,?,?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, e.getId_evento());
            stmt.setString(2, e.getNome());
            stmt.setDate(3, md.String2Date(e.getData()));
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                e.setId_evento(rs.getInt("id_evento"));
            }
            else{
                e.setId_evento(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
      
        return e;
    }
    
    public void editar(Eventos e){
        
        try{
            PreparedStatement stmt = conn.prepareStatement("UPDATE eventos SET nome = ?, data = ?, id = ?" + "where id_evento= ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, e.getNome());
            stmt.setString(2, e.getData());
            stmt.setInt(3, e.getId_evento());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                e.setId_evento(rs.getInt("id_evento"));
            }
            else{
                e.setId_evento(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    
     public int excluir(Eventos e){
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM eventos where id_evento= ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, e.getId_evento());
            verif = stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                e.setId_evento(rs.getInt("id_evento"));
            }
            else{
                e.setId_evento(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
   
     
    public List<Eventos>getEventos(){
        List<Eventos> lstE = new ArrayList();
        
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM evento", Statement.RETURN_GENERATED_KEYS);
            
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstE.add(getEventos(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstE;
    }
     
    public List<Eventos> getEventos(Eventos e){
        
        List<Eventos> lstE = new ArrayList<>();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM evento where nome ILIKE ?", Statement.RETURN_GENERATED_KEYS);
            ppStmt.setString(1, e.getNome()+ "%");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstE.add(getEventos(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstE;
    }
     
    private Eventos getEventos(ResultSet rs) throws SQLException {
        
        Eventos e = new Eventos();
        e.setId_evento(rs.getInt("id_eventos"));
        e.setNome(rs.getString("nome"));
        e.setData(rs.getString("data"));
        
        return e;
    }   
}

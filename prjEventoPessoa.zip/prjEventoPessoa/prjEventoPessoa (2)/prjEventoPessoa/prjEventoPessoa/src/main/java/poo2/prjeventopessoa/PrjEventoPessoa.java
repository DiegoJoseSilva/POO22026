package poo2.prjeventopessoa;

public class PrjEventoPessoa {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

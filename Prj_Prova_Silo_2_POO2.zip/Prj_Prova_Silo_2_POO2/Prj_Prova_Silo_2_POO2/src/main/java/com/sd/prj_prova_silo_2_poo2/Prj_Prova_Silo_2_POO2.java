package com.sd.prj_prova_silo_2_poo2;

/**
 *
 * @author user
 */
public class Prj_Prova_Silo_2_POO2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

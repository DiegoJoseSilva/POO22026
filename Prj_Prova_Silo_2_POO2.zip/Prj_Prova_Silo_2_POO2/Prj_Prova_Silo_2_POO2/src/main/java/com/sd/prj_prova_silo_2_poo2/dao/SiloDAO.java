package com.sd.prj_prova_silo_2_poo2.dao;

import com.sd.prj_prova_silo_2_poo2.models.Carga;
import com.sd.prj_prova_silo_2_poo2.models.Silo;
import com.sd.prj_prova_silo_2_poo2.util.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SiloDAO {
    
    Connection conn;
    
    public SiloDAO() {
            conn = new Conexao().conectar();
    }
    public List<Silo> listarTodos() {

        List<Silo> lista = new ArrayList<>();

        try {

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM silo");

            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {

                Silo s = new Silo();
                
                s.setId(rs.getInt("id"));
                s.setDescricao(rs.getString("descricao"));
                s.setCapacidadeMaxima(rs.getDouble("capacidade_maxima"));
                s.setVolumeAtual(rs.getDouble("volume_atual"));

                lista.add(s);
            }

        } catch(SQLException ex) {
            ex.printStackTrace();
        }

        return lista;
    }
    
    
    public Silo buscarPorId(int id) throws Exception{

        String sql="select * from silo where id=?";

        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setInt(1,id);

        ResultSet rs=stmt.executeQuery();

        if(rs.next()){

            Silo s=new Silo();

            s.setId(rs.getInt("id"));
            s.setDescricao(rs.getString("descricao"));
            s.setCapacidadeMaxima(rs.getDouble("capacidade_maxima"));
            s.setVolumeAtual(rs.getDouble("volume_atual"));

            return s;
        }

        return null;
    }
    public void processarNovaCarga(int id_silo, double peso){
        
         try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO carga(id_silo, peso_toneladas, ) values(?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, id_silo);
            stmt.setDouble(2, peso);
            
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                System.out.println("Dados Salvos");
            }
            else{
                System.out.println("Erro ao salvar");
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    
    public void registrarTransacao(Carga carga, Silo silo) throws Exception{


        try{

            conn.setAutoCommit(false);

            String sqlCarga=
                    "insert into carga(id_silo,peso) values(?,?)";

            PreparedStatement ps1=
                    conn.prepareStatement(sqlCarga);

            ps1.setInt(1,carga.getIdSilo());
            ps1.setDouble(2,carga.getPesoToneladas());

            ps1.executeUpdate();

            String sqlSilo=
                    "update silo set volume_atual=? where id=?";

            PreparedStatement ps2=
                    conn.prepareStatement(sqlSilo);

            ps2.setDouble(1,silo.getVolumeAtual());
            ps2.setInt(2,silo.getId());

            ps2.executeUpdate();

            conn.commit();

        }catch(Exception e){

            conn.rollback();

            throw e;

        }finally{

            conn.setAutoCommit(true);

        }

    }
}

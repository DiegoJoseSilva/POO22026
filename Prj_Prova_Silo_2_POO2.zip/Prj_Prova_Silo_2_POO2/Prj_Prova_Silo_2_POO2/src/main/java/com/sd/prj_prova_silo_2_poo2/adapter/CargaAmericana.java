package com.sd.prj_prova_silo_2_poo2.adapter;

public class CargaAmericana {

    private int siloId;
    private double weightLbs;

    public CargaAmericana(int siloId, double weightLbs){
        this.siloId = siloId;
        this.weightLbs = weightLbs;
    }

    public int getSiloId() {
        return siloId;
    }

    public double getWeightLbs() {
        return weightLbs;
    }
}
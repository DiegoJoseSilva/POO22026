package com.sd.prj_prova_silo_2_poo2.factory;

import com.sd.prj_prova_silo_2_poo2.adapter.AdaptadorCargaImportada;
import com.sd.prj_prova_silo_2_poo2.adapter.CargaAmericana;
import com.sd.prj_prova_silo_2_poo2.adapter.CargaNacional;
import com.sd.prj_prova_silo_2_poo2.models.Carga;

public class CargaFactory {

    public static Carga criarCarga(String tipoOrigem,
                                   int idSilo,
                                   double peso){

        if(tipoOrigem.equalsIgnoreCase("Importada")){

            return new AdaptadorCargaImportada(new CargaAmericana(idSilo,peso)
            );
        }

        return new CargaNacional(idSilo,peso);

    }

}

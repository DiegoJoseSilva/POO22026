package com.sd.prj_prova_silo_2_poo2.adapter;

import com.sd.prj_prova_silo_2_poo2.models.Carga;


public class CargaNacional implements Carga{

    private int idSilo;
    private double pesoToneladas;

    public CargaNacional(int idSilo, double pesoToneladas){
        this.idSilo = idSilo;
        this.pesoToneladas = pesoToneladas;
    }

    @Override
    public int getIdSilo() {
        return idSilo;
    }

    @Override
    public double getPesoToneladas() {
        return pesoToneladas;
    }
}

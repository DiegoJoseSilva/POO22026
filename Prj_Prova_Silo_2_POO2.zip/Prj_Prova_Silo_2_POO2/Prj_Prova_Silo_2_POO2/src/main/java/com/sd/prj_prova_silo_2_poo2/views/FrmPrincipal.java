package com.sd.prj_prova_silo_2_poo2.views;

import com.sd.prj_prova_silo_2_poo2.controllers.SiloController;
import com.sd.prj_prova_silo_2_poo2.models.Silo;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class FrmPrincipal extends JFrame {
    private JComboBox<String> cbOrigem;
    private JTextField txtIdSilo, txtPeso;
    private JTable tabela;
    private DefaultTableModel tableModel;
    private SiloController controller;

    public FrmPrincipal() {
        controller = new SiloController();
        
        setTitle("Gestão Final de Silos e Cargas");
        setSize(750, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Formulário Superior
        JPanel pnlTopo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        cbOrigem = new JComboBox<>(new String[]{"Nacional", "Importada"});
        txtIdSilo = new JTextField(5);
        txtPeso = new JTextField(8);
        JButton btnSalvar = new JButton("Descarregar Caminhão");

        pnlTopo.add(new JLabel("Origem:"));
        pnlTopo.add(cbOrigem);
        pnlTopo.add(new JLabel("ID Silo:"));
        pnlTopo.add(txtIdSilo);
        pnlTopo.add(new JLabel("Peso (Ton/Lbs):"));
        pnlTopo.add(txtPeso);
        pnlTopo.add(btnSalvar);

        add(pnlTopo, BorderLayout.NORTH);

        // Tabela Central
        String[] colunas = {"ID Silo", "Descrição", "Capacidade Máxima", "Volume Ocupado"};
        tableModel = new DefaultTableModel(colunas, 0);
        tabela = new JTable(tableModel);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        // Eventos
        btnSalvar.addActionListener(e -> acaoSalvar());

        carregarTabela();
    }

    private void acaoSalvar() {
        try {
            String origem = cbOrigem.getSelectedItem().toString();
            int idSilo = Integer.parseInt(txtIdSilo.getText());
            double peso = Double.parseDouble(txtPeso.getText().replace(",", "."));

            controller.processarNovaCarga(origem, idSilo, peso);
            
            JOptionPane.showMessageDialog(this, "Carga registrada e volume atualizado!");
            
            txtIdSilo.setText("");
            txtPeso.setText("");
            carregarTabela();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Preencha valores numéricos válidos.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Aviso: " + ex.getMessage(), "Alerta de Negócio", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void carregarTabela() {
        tableModel.setRowCount(0);
        try {
            for (Silo silo : controller.buscarTodosSilos()) {
                tableModel.addRow(new Object[]{
                        silo.getId(), 
                        silo.getDescricao(), 
                        String.format("%.2f Ton", silo.getCapacidadeMaxima()), 
                        String.format("%.2f Ton", silo.getVolumeAtual())
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Falha na comunicação com o banco.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FrmPrincipal().setVisible(true));
    }
}

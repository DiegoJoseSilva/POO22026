package com.sd.prj_prova_silo_2_poo2.models;

import java.sql.Date;


public interface Carga {

    int getIdSilo();

    double getPesoToneladas();

}

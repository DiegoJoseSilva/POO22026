package com.sd.prj_prova_silo_2_poo2.controllers;

import com.sd.prj_prova_silo_2_poo2.dao.SiloDAO;
import com.sd.prj_prova_silo_2_poo2.factory.CargaFactory;
import com.sd.prj_prova_silo_2_poo2.models.Carga;
import com.sd.prj_prova_silo_2_poo2.models.Silo;
import java.util.List;

public class SiloController {
    
    SiloDAO cDAO = new SiloDAO();
    CargaFactory factory = new CargaFactory();
    

    public void processarNovaCarga(String origem,
         int idSilo,
         double peso) throws Exception{

        Carga carga =
                CargaFactory.criarCarga(origem,idSilo,peso);

        Silo silo = cDAO.buscarPorId(idSilo);

        if(silo==null){

            throw new Exception("Silo não encontrado.");

        }

        if(silo.getVolumeAtual()+carga.getPesoToneladas()
                > silo.getCapacidadeMaxima()){

            throw new Exception("Capacidade excedida.");

        }

        silo.setVolumeAtual(
                silo.getVolumeAtual()
                + carga.getPesoToneladas());

        cDAO.registrarTransacao(carga,silo);

    }
    

    public List<Silo> buscarTodosSilos() throws Exception{

        return cDAO.listarTodos();

    }
    
}

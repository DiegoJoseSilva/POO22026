package com.sd.prj_prova_silo_2_poo2.adapter;

import com.sd.prj_prova_silo_2_poo2.models.Carga;


public class AdaptadorCargaImportada implements Carga {

    private CargaAmericana carga;

    public AdaptadorCargaImportada(CargaAmericana carga){
        this.carga = carga;
    }

    @Override
    public int getIdSilo() {
        return carga.getSiloId();
    }

    @Override
    public double getPesoToneladas() {

        return carga.getWeightLbs() * 0.000453592;
    }
}

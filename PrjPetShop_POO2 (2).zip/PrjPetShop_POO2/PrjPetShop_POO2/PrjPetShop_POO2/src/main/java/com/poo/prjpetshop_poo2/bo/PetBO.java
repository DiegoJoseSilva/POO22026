package com.poo.prjpetshop_poo2.bo;

public class PetBO {
    
    PetBO petBO;
    
    
}

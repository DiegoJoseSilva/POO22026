package com.poo.prj_strategy_observer.forms;

import com.poo.prj_strategy_observer.Strategy.CalorStrategy;
import com.poo.prj_strategy_observer.Strategy.ClimaStrategy;
import com.poo.prj_strategy_observer.Strategy.FrioStrategy;
import com.poo.prj_strategy_observer.Subject.EstacaoMeterologica;
import com.poo.prj_strategy_observer.observer.ObservadorTemperatura;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class TelaClima extends JFrame implements ObservadorTemperatura {
    private EstacaoMeterologica estacao;
    private ClimaStrategy estrategiaAtual;
    
    private JLabel lblStatus = new JLabel("Temperatura; 0º");
    private JLabel lblDica = new JLabel("Aguardando...");
    private JTextField txtTemp = new JTextField(5);
    
    public TelaClima(){
        estacao = new EstacaoMeterologica();
        estacao.registrar(this);
        
        setTitle("Monitor de clima 1.0");
        setSize(300,200);
        setLayout(new FlowLayout());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        JButton btnAlterar = new JButton("Atualizar");
        add(new JLabel ("Nova temp: "));
        add(txtTemp);
        add(btnAlterar);
        add(lblStatus);
        add(lblDica);
        
        btnAlterar.addActionListener(e ->{
            double t = Double.parseDouble(txtTemp.getText());
            estacao.setTemperatura(t);
        });
    }
    
    @Override
    public void temperaturaMudou(double novaTemp){
        lblStatus.setText("Temperatura atual: "+ novaTemp + "º c");
        
        if(novaTemp < 15){
            estrategiaAtual = new FrioStrategy();
        }else{
            estrategiaAtual = new CalorStrategy();
        }
        
        lblDica.setText(estrategiaAtual.avaliar(novaTemp));
    }
    
    public static void main(String[] args){
        new TelaClima().setVisible(true);
    }
}

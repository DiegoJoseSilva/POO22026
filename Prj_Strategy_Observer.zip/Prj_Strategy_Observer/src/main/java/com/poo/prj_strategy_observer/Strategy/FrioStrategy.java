/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_strategy_observer.Strategy;

/**
 *
 * @author Iftm
 */
public class FrioStrategy implements ClimaStrategy{
    public String avaliar(double temp){
        return "Está congelando! Use um casaco"; 
    }
}

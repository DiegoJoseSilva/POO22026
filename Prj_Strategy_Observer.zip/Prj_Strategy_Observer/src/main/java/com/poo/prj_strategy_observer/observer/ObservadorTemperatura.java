package com.poo.prj_strategy_observer.observer;


public interface ObservadorTemperatura {
    void temperaturaMudou(double novaTemp);
}

package com.poo.prj_strategy_observer.Strategy;

public interface ClimaStrategy {
    String avaliar(double temp);
}

package com.poo.prj_strategy_observer.Subject;

import com.poo.prj_strategy_observer.observer.ObservadorTemperatura;
import java.util.ArrayList;
import java.util.List;


public class EstacaoMeterologica {
    private List<ObservadorTemperatura> observadores = new ArrayList<>();
    private double temperatura;
    
    public void registrar(ObservadorTemperatura obs){
        observadores.add(obs);
    }
    
    public void setTemperatura(double temp){
            this.temperatura=temp;
            notificarTodos();
    }
    
    private void notificarTodos(){
        for(ObservadorTemperatura obs:observadores){
            obs.temperaturaMudou(temperatura);
        }
    }
}

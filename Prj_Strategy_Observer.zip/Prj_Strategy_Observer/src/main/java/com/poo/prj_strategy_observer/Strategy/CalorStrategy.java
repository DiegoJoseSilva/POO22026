package com.poo.prj_strategy_observer.Strategy;

/**
 *
 * @author Iftm
 */
public class CalorStrategy  implements ClimaStrategy{
    public String avaliar(double temp){
        return "Calor intenso!Beba muita água";
    }
}

package com.mycompany.calculadora_grafica;

public class Calculadora_Grafica {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
